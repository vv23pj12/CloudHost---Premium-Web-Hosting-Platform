import React from 'react';
import { 
  Server, 
  Cpu, 
  ShieldCheck, 
  Clock, 
  Zap, 
  Globe, 
  LifeBuoy, 
  Database 
} from 'lucide-react';
import { PricingPlan, Feature, Testimonial, BlogPost } from './types.ts';

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'basic',
    name: 'Shared Hosting',
    price: '$2.99',
    description: 'Perfect for small blogs and personal websites.',
    features: ['1 Website', '10GB SSD Storage', '100GB Bandwidth', 'Free SSL', '24/7 Support']
  },
  {
    id: 'pro',
    name: 'Cloud VPS',
    price: '$12.99',
    description: 'High performance for growing businesses.',
    features: ['Unlimited Websites', '100GB NVMe SSD', 'Unlimited Bandwidth', 'Dedicated IP', 'Advanced Security', 'Weekly Backups'],
    isPopular: true
  },
  {
    id: 'enterprise',
    name: 'Dedicated Server',
    price: '$89.00',
    description: 'Ultimate power for heavy workloads.',
    features: ['Custom Configuration', '1TB NVMe Storage', '1Gbps Network', 'DDoS Protection', 'Full Root Access', 'Managed Support']
  }
];

export const FEATURES: Feature[] = [
  {
    title: 'Super Fast NVMe SSD',
    description: 'Experience blazing fast load times with our high-end storage solutions.',
    icon: <Zap className="w-6 h-6 text-indigo-600" />
  },
  {
    title: '99.9% Uptime Guarantee',
    description: 'Your business never sleeps, and neither does our robust infrastructure.',
    icon: <Clock className="w-6 h-6 text-indigo-600" />
  },
  {
    title: 'Global Data Centers',
    description: 'Choose from 20+ locations worldwide to serve your users faster.',
    icon: <Globe className="w-6 h-6 text-indigo-600" />
  },
  {
    title: 'Advanced Security',
    description: 'Multi-layer DDoS protection and real-time malware scanning.',
    icon: <ShieldCheck className="w-6 h-6 text-indigo-600" />
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Alex Johnson',
    role: 'CEO at TechStream',
    content: 'The migration was seamless. Our site speed increased by 40% immediately after moving to CloudHost.',
    avatar: 'https://picsum.photos/100/100?random=1'
  },
  {
    name: 'Sarah Chen',
    role: 'Full Stack Developer',
    content: 'Best VPS performance I have ever tested. Their support team actually knows what they are talking about.',
    avatar: 'https://picsum.photos/100/100?random=2'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'How to Choose the Right Hosting for Your Business',
    excerpt: 'Finding the perfect hosting environment can be daunting. We break down the key differences between Shared, VPS, and Dedicated.',
    author: 'Mark Veran',
    date: 'Oct 12, 2024',
    category: 'Guides',
    image: 'https://picsum.photos/600/400?random=blog1'
  },
  {
    id: '2',
    title: 'The Future of NVMe Storage in Web Hosting',
    excerpt: 'Speed is everything in 2024. Learn why NVMe is replacing standard SSDs as the industry standard for performance.',
    author: 'Elena Smith',
    date: 'Oct 15, 2024',
    category: 'Technology',
    image: 'https://picsum.photos/600/400?random=blog2'
  },
  {
    id: '3',
    title: '10 Security Tips to Protect Your VPS',
    excerpt: 'A basic guide to hardening your Linux server from common cyber threats and brute-force attacks.',
    author: 'Sam Wilson',
    date: 'Oct 18, 2024',
    category: 'Security',
    image: 'https://picsum.photos/600/400?random=blog3'
  }
];

export const DOMAIN_EXTENSIONS = [
  { name: '.com', price: '$8.99', oldPrice: '$12.99' },
  { name: '.net', price: '$10.99', oldPrice: '$15.99' },
  { name: '.org', price: '$12.99', oldPrice: '$18.99' },
  { name: '.io', price: '$24.99', oldPrice: '$35.99' },
  { name: '.me', price: '$5.99', oldPrice: '$9.99' },
  { name: '.store', price: '$0.99', oldPrice: '$12.99' },
];