// Fix: Import React to resolve the 'Cannot find namespace React' error for React.ReactNode
import React from 'react';

export type Page = 
  | 'home' 
  | 'services' 
  | 'pricing' 
  | 'about' 
  | 'contact' 
  | 'domains' 
  | 'blog' 
  | 'blog-post'
  | 'shared-hosting'
  | 'cpanel-hosting'
  | 'cloud-vps'
  | 'dedicated-servers'
  | 'affiliate'
  | 'careers'
  | 'client-dashboard'
  | 'knowledgebase'
  | 'support-tickets';

export type ThemeColor = 'blue' | 'purple' | 'green' | 'orange';

export interface PricingPlan {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
}

export interface Feature {
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface Testimonial {
  name: string;
  role: string;
  content: string;
  avatar: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  category: string;
  image: string;
}