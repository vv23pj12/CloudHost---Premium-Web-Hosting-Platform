
import React from 'react';
import { Server, CheckCircle2, Shield, Zap, Globe, LifeBuoy } from 'lucide-react';

const SharedHosting: React.FC = () => {
  const plans = [
    {
      name: 'Single',
      price: '$1.99',
      desc: 'Ideal for beginners starting their first website.',
      features: ['1 Website', '50 GB SSD', '100 GB Bandwidth', 'Standard Performance']
    },
    {
      name: 'Premium',
      price: '$2.99',
      desc: 'Perfect for growing small business websites.',
      features: ['100 Websites', '100 GB SSD', 'Unlimited Bandwidth', '2X Performance', 'Free Domain'],
      popular: true
    },
    {
      name: 'Business',
      price: '$4.99',
      desc: 'Optimized for high-traffic sites and eCommerce.',
      features: ['100 Websites', '200 GB NVMe SSD', 'Unlimited Bandwidth', '5X Performance', 'Free Domain', 'Daily Backups']
    }
  ];

  return (
    <div className="bg-white">
      <section className="gradient-bg py-24 text-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-black mb-6 font-poppins leading-tight">Fast & Reliable <br/>Shared Hosting</h1>
          <p className="text-xl opacity-90 mb-10">Everything you need to launch your website in minutes. User-friendly control panel and expert support included.</p>
          <div className="flex flex-wrap justify-center gap-8">
            <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-400" /> Free SSL</div>
            <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-400" /> 1-Click WordPress</div>
            <div className="flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-green-400" /> 30-Day Guarantee</div>
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, i) => (
            <div key={i} className={`p-10 rounded-[2.5rem] border ${plan.popular ? 'border-indigo-600 shadow-2xl relative' : 'border-gray-100 shadow-sm'} transition-all hover:-translate-y-2`}>
              {plan.popular && <span className="absolute top-0 right-10 -translate-y-1/2 bg-indigo-600 text-white px-4 py-1 rounded-full text-xs font-bold">BEST VALUE</span>}
              <h3 className="text-2xl font-bold mb-2 font-poppins">{plan.name}</h3>
              <div className="mb-6">
                <span className="text-4xl font-black">{plan.price}</span>
                <span className="text-gray-500">/mo</span>
              </div>
              <p className="text-gray-600 text-sm mb-8">{plan.desc}</p>
              <ul className="space-y-4 mb-10">
                {plan.features.map((f, idx) => (
                  <li key={idx} className="flex items-center gap-3 text-sm font-medium text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-indigo-500 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button className={`w-full py-4 rounded-2xl font-black transition-all ${plan.popular ? 'gradient-bg text-white' : 'bg-gray-100 text-gray-800 hover:bg-gray-200'}`}>
                Choose {plan.name}
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
          <div>
            <div className="bg-indigo-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Zap className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-xl font-bold mb-4 font-poppins">LightSpeed Cache</h3>
            <p className="text-gray-600">Advanced caching technologies to ensure your site loads at blazing speeds.</p>
          </div>
          <div>
            <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold mb-4 font-poppins">Auto-Backups</h3>
            <p className="text-gray-600">Your data is safe with us. Weekly or daily backups depending on your plan.</p>
          </div>
          <div>
            <div className="bg-green-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <LifeBuoy className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold mb-4 font-poppins">24/7 Expert Help</h3>
            <p className="text-gray-600">Our support engineers are always online to help you with any issues.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default SharedHosting;
