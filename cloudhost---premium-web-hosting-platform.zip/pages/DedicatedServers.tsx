import React from 'react';
import { Cpu, Server, ShieldCheck, Zap, ArrowRight, Settings, MousePointer2 } from 'lucide-react';

const DedicatedServers: React.FC = () => {
  const hardware = [
    { name: 'AMD EPYC™ 7402P', cores: '24 Cores / 48 Threads', ram: '128 GB DDR4', storage: '2x 960 GB NVMe', network: '10 Gbps', price: '$149' },
    { name: 'Intel® Xeon® Gold 6230', cores: '20 Cores / 40 Threads', ram: '256 GB DDR4', storage: '4x 1 TB NVMe', network: '20 Gbps', price: '$289', popular: true },
    { name: 'Custom Enterprise', cores: 'Up to 128 Cores', ram: '2 TB DDR4', storage: 'Custom Array', network: '100 Gbps', price: 'Custom' },
  ];

  return (
    <div className="bg-white">
      <section className="py-24 bg-slate-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-black mb-8 font-poppins">Bare Metal <span className="gradient-text">Power.</span></h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">Unleash the full potential of your application with raw, dedicated hardware. No noisy neighbors, no virtualization overhead—just pure performance.</p>
          <div className="flex justify-center gap-12 flex-wrap">
            <div className="flex items-center gap-3 font-bold text-gray-800"><Cpu className="text-indigo-600" /> AMD EPYC™ & Intel® Xeon®</div>
            <div className="flex items-center gap-3 font-bold text-gray-800"><ShieldCheck className="text-indigo-600" /> Full Root Control</div>
            <div className="flex items-center gap-3 font-bold text-gray-800"><Zap className="text-indigo-600" /> 100% Dedicated Port</div>
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="space-y-6">
          {hardware.map((item, i) => (
            <div key={i} className={`flex flex-col lg:flex-row items-center gap-8 p-10 rounded-[2.5rem] border transition-all ${item.popular ? 'border-indigo-600 shadow-2xl bg-indigo-50/20' : 'border-gray-100 bg-white hover:shadow-md'}`}>
              <div className="bg-indigo-600 text-white p-6 rounded-3xl">
                 <Server className="w-12 h-12" />
              </div>
              <div className="flex-1 text-center lg:text-left">
                <h3 className="text-2xl font-black font-poppins mb-4">{item.name}</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-sm text-gray-600">
                  <div><p className="font-bold text-gray-900">{item.cores}</p><p>Processors</p></div>
                  <div><p className="font-bold text-gray-900">{item.ram}</p><p>Memory</p></div>
                  <div><p className="font-bold text-gray-900">{item.storage}</p><p>Storage</p></div>
                  <div><p className="font-bold text-gray-900">{item.network}</p><p>Network Uplink</p></div>
                </div>
              </div>
              <div className="text-center lg:text-right min-w-[180px]">
                 <div className="mb-4">
                    <span className="text-4xl font-black">{item.price}</span>
                    {item.price !== 'Custom' && <span className="text-gray-500 text-sm">/mo</span>}
                 </div>
                 <button className={`w-full py-4 rounded-xl font-bold transition-all ${item.popular ? 'gradient-bg text-white' : 'bg-gray-900 text-white'}`}>
                   {item.price === 'Custom' ? 'Talk to Sales' : 'Configure Server'}
                 </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-indigo-900 text-white overflow-hidden relative">
         <div className="max-w-7xl mx-auto px-4 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
               <div>
                  <h2 className="text-4xl font-black mb-8 font-poppins leading-tight">Managed Dedicated <br/> Support Included.</h2>
                  <p className="text-lg text-indigo-200 mb-10">Don't let hardware management slow you down. Our expert sysadmins handle the monitoring, updates, and maintenance while you focus on building.</p>
                  <ul className="space-y-4">
                     <li className="flex items-center gap-3"><div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-xs">1</div> 24/7 Proactive Monitoring</li>
                     <li className="flex items-center gap-3"><div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-xs">2</div> Hardware Replacement in 2 Hours</li>
                     <li className="flex items-center gap-3"><div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-xs">3</div> Operating System Installation</li>
                     <li className="flex items-center gap-3"><div className="w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center text-xs">4</div> Custom Firewall Configuration</li>
                  </ul>
               </div>
               <div className="relative">
                  <img src="https://picsum.photos/800/600?random=datacenter" className="rounded-[3rem] shadow-2xl" />
                  <div className="absolute -top-10 -left-10 bg-indigo-600 p-8 rounded-3xl shadow-2xl hidden lg:block">
                     <p className="text-4xl font-black">99.9%</p>
                     <p className="text-sm uppercase tracking-widest font-bold opacity-80">Network SLA</p>
                  </div>
               </div>
            </div>
         </div>
      </section>
    </div>
  );
};

export default DedicatedServers;