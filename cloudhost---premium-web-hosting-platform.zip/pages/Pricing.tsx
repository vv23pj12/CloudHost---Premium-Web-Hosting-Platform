
import React, { useState } from 'react';
import { Check, X, Info, Zap, HelpCircle, ArrowRight } from 'lucide-react';

const Pricing: React.FC = () => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');
  const [viewMode, setViewMode] = useState<'cards' | 'comparison'>('cards');

  const plans = [
    {
      name: 'Lite',
      monthly: '$4.99',
      yearly: '$2.99',
      desc: 'Ideal for small blogs',
      features: ['1 Website', '10GB Storage', '100GB Bandwidth', 'Free SSL', '24/7 Support'],
      limitations: ['No Pro Backups', 'Standard CPU', 'No Dedicated IP']
    },
    {
      name: 'Business',
      monthly: '$15.99',
      yearly: '$12.99',
      desc: 'Perfect for scaling',
      features: ['10 Websites', '100GB Storage', 'Unlimited Bandwidth', 'Free SSL', '24/7 Support', 'Daily Backups', 'Free Domain'],
      popular: true
    },
    {
      name: 'Pro Cloud',
      monthly: '$35.99',
      yearly: '$29.99',
      desc: 'Maximum performance',
      features: ['Unlimited Websites', '250GB Storage', 'Unlimited Bandwidth', 'Advanced Security', 'Dedicated IP', 'Weekly Backups', 'Priority Support']
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-32">
      {/* Header */}
      <section className="bg-white pt-24 pb-48 text-center px-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-[0.03] pointer-events-none font-black text-[30rem] select-none leading-none -translate-x-1/2 translate-y-1/2">
           PRICING
        </div>
        <div className="max-w-4xl mx-auto relative z-10">
          <span className="text-indigo-600 font-black uppercase tracking-widest text-sm mb-4 block">No Surprise Billing</span>
          <h1 className="text-5xl md:text-7xl font-black mb-8 font-poppins leading-tight">Plans that scale <br/><span className="gradient-text">with your success.</span></h1>
          
          <div className="flex items-center justify-center gap-6 mt-12 bg-gray-100 w-fit mx-auto p-1.5 rounded-2xl border border-gray-200">
             <button 
                onClick={() => setBillingCycle('monthly')}
                className={`px-8 py-3 rounded-xl font-bold transition-all ${billingCycle === 'monthly' ? 'bg-white text-gray-900 shadow-md' : 'text-gray-500 hover:text-indigo-600'}`}
             >
                Monthly
             </button>
             <button 
                onClick={() => setBillingCycle('yearly')}
                className={`px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2 ${billingCycle === 'yearly' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-gray-500 hover:text-indigo-600'}`}
             >
                Yearly <span className="bg-white/20 px-2 py-0.5 rounded-lg text-[10px] uppercase font-black">Save 20%</span>
             </button>
          </div>
        </div>
      </section>

      {/* Main Pricing View */}
      <div className="max-w-7xl mx-auto px-4 -mt-32 relative z-20">
        
        {/* Toggle Mode */}
        <div className="flex justify-end mb-8">
           <div className="bg-white p-1 rounded-xl shadow-sm border border-gray-100 flex">
              <button 
                onClick={() => setViewMode('cards')}
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${viewMode === 'cards' ? 'bg-indigo-600 text-white' : 'text-gray-500'}`}
              >
                Cards
              </button>
              <button 
                onClick={() => setViewMode('comparison')}
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${viewMode === 'comparison' ? 'bg-indigo-600 text-white' : 'text-gray-500'}`}
              >
                Comparison
              </button>
           </div>
        </div>

        {viewMode === 'cards' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, i) => (
              <div key={i} className={`bg-white rounded-[3rem] overflow-hidden border transition-all duration-500 ${plan.popular ? 'border-indigo-600 shadow-[0_32px_64px_-16px_rgba(79,70,229,0.2)] scale-105' : 'border-gray-100 hover:shadow-2xl'}`}>
                <div className="p-10 text-center">
                  <h3 className="text-xl font-black text-gray-900 uppercase tracking-widest mb-4">{plan.name}</h3>
                  <div className="mb-6">
                    <span className="text-6xl font-black text-gray-900">{billingCycle === 'yearly' ? plan.yearly : plan.monthly}</span>
                    <span className="text-gray-400 font-bold ml-1">/mo</span>
                  </div>
                  <p className="text-sm text-gray-500 font-medium mb-8 px-8">{plan.desc}</p>
                  <button className={`w-full py-5 rounded-2xl font-black text-lg transition-all ${plan.popular ? 'gradient-bg text-white shadow-xl hover:scale-[1.02]' : 'bg-slate-100 text-gray-900 hover:bg-slate-200'}`}>
                    Choose Plan
                  </button>
                </div>
                <div className="p-10 bg-slate-50 border-t border-gray-100 space-y-4">
                  {plan.features.map((f, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      <div className="bg-indigo-100 p-1 rounded-full"><Check className="w-3 h-3 text-indigo-600" /></div>
                      <span className="text-sm font-bold text-gray-700">{f}</span>
                    </div>
                  ))}
                  {plan.limitations?.map((l, idx) => (
                    <div key={idx} className="flex items-center gap-3 opacity-40 grayscale">
                      <div className="bg-gray-200 p-1 rounded-full"><X className="w-3 h-3 text-gray-500" /></div>
                      <span className="text-sm font-medium text-gray-500">{l}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-[3rem] shadow-2xl border border-gray-100 overflow-hidden animate-in fade-in zoom-in-95 duration-500">
             <table className="w-full text-left border-collapse">
                <thead>
                   <tr className="border-b border-gray-100">
                      <th className="p-10 text-2xl font-black font-poppins">Feature</th>
                      {plans.map(p => (
                        <th key={p.name} className="p-10 text-center">
                           <div className="text-xs font-black text-indigo-600 uppercase mb-2">{p.name}</div>
                           <div className="text-2xl font-black">{billingCycle === 'yearly' ? p.yearly : p.monthly}</div>
                        </th>
                      ))}
                   </tr>
                </thead>
                <tbody className="text-sm font-bold text-gray-700">
                   <tr className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="px-10 py-6">Website Count</td>
                      <td className="p-6 text-center">1</td>
                      <td className="p-6 text-center">10</td>
                      <td className="p-6 text-center">Unlimited</td>
                   </tr>
                   <tr className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="px-10 py-6">NVMe SSD Storage</td>
                      <td className="p-6 text-center">10 GB</td>
                      <td className="p-6 text-center">100 GB</td>
                      <td className="p-6 text-center">250 GB</td>
                   </tr>
                   <tr className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="px-10 py-6">Free Domain (.com)</td>
                      <td className="p-6 text-center"><X className="mx-auto w-5 h-5 text-gray-300" /></td>
                      <td className="p-6 text-center"><Check className="mx-auto w-5 h-5 text-green-500" /></td>
                      <td className="p-6 text-center"><Check className="mx-auto w-5 h-5 text-green-500" /></td>
                   </tr>
                   <tr className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="px-10 py-6">Daily Pro Backups</td>
                      <td className="p-6 text-center"><X className="mx-auto w-5 h-5 text-gray-300" /></td>
                      <td className="p-6 text-center"><Check className="mx-auto w-5 h-5 text-green-500" /></td>
                      <td className="p-6 text-center"><Check className="mx-auto w-5 h-5 text-green-500" /></td>
                   </tr>
                   <tr className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="px-10 py-6">Priority 24/7 Support</td>
                      <td className="p-6 text-center"><X className="mx-auto w-5 h-5 text-gray-300" /></td>
                      <td className="p-6 text-center"><X className="mx-auto w-5 h-5 text-gray-300" /></td>
                      <td className="p-6 text-center"><Check className="mx-auto w-5 h-5 text-green-500" /></td>
                   </tr>
                </tbody>
             </table>
          </div>
        )}

        {/* Enterprise Banner */}
        <div className="mt-20 gradient-bg rounded-[3rem] p-12 md:p-16 text-white flex flex-col md:flex-row items-center justify-between gap-12">
           <div className="max-w-xl text-center md:text-left">
              <h2 className="text-4xl font-black mb-6 font-poppins">Looking for <br/>Custom Enterprise?</h2>
              <p className="text-indigo-100 text-lg">We offer custom architecture for high-traffic apps, gaming servers, and data-heavy enterprises. Let's build your dream stack.</p>
           </div>
           <button className="bg-white text-indigo-700 px-12 py-5 rounded-2xl font-black text-xl hover:scale-105 active:scale-95 transition-all shadow-2xl flex items-center gap-3">
              Contact Sales <ArrowRight className="w-6 h-6" />
           </button>
        </div>

        {/* FAQs Section */}
        <div className="mt-32 max-w-4xl mx-auto">
          <h2 className="text-4xl font-black text-center mb-16 font-poppins">Got Questions?</h2>
          <div className="space-y-6">
             {[
               { q: 'Can I cancel my subscription anytime?', a: 'Yes, you can cancel your plan at any time from your dashboard with one click.' },
               { q: 'What is your uptime guarantee?', a: 'We offer a 99.9% uptime guarantee backed by our industry-leading SLA.' },
               { q: 'How does the free domain work?', a: 'Eligible yearly plans include a free .com, .net, or .org registration for the first year.' }
             ].map((item, i) => (
               <div key={i} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm flex gap-6">
                  <div className="bg-indigo-50 p-3 rounded-2xl h-fit text-indigo-600"><HelpCircle className="w-6 h-6" /></div>
                  <div>
                    <h4 className="text-xl font-bold mb-3">{item.q}</h4>
                    <p className="text-gray-600 leading-relaxed">{item.a}</p>
                  </div>
               </div>
             ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Pricing;
