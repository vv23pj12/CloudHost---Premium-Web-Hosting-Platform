
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="relative py-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-indigo-600 font-bold tracking-widest text-sm uppercase">About CloudHost</span>
              <h1 className="text-4xl md:text-5xl font-extrabold mt-4 mb-8 leading-tight">
                Our mission is to empower the next generation of digital creators.
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                Founded in 2015, CloudHost has grown from a small startup to one of the world's most trusted hosting providers. We believe that everyone should have access to high-performance infrastructure.
              </p>
              <div className="grid grid-cols-2 gap-8">
                <div>
                  <div className="text-3xl font-bold text-indigo-600">100+</div>
                  <div className="text-gray-500 text-sm">Engineers</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-indigo-600">24/7</div>
                  <div className="text-gray-500 text-sm">Active Support</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://picsum.photos/600/400?random=about" 
                alt="Our Team" 
                className="rounded-3xl shadow-2xl z-10 relative"
              />
              <div className="absolute -top-6 -right-6 w-32 h-32 bg-indigo-100 rounded-full -z-0"></div>
              <div className="absolute -bottom-6 -left-6 w-48 h-48 bg-cyan-100 rounded-3xl -z-0"></div>
            </div>
          </div>
        </div>
      </div>

      <section className="bg-slate-50 py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-16">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <div className="text-5xl mb-6">🚀</div>
              <h3 className="text-xl font-bold mb-4">Innovation First</h3>
              <p className="text-gray-600">We constantly push the boundaries of what is possible in hosting technology.</p>
            </div>
            <div>
              <div className="text-5xl mb-6">🛡️</div>
              <h3 className="text-xl font-bold mb-4">Security Obsessed</h3>
              <p className="text-gray-600">Your data's safety is our top priority. We build security into every layer.</p>
            </div>
            <div>
              <div className="text-5xl mb-6">🤝</div>
              <h3 className="text-xl font-bold mb-4">Customer Obsession</h3>
              <p className="text-gray-600">We don't just sell hosting; we partner with you to ensure your success.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
