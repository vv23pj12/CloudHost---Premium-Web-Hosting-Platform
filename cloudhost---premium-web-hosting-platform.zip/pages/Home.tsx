import React from 'react';
import { Search, Server, Shield, Zap, CheckCircle2, Globe, ArrowRight, Cloud, Database } from 'lucide-react';
import { FEATURES, PRICING_PLANS, TESTIMONIALS } from '../constants.tsx';
import ContentSection from '../components/ContentSection.tsx';
import TestimonialSlider from '../components/TestimonialSlider.tsx';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-slate-50 pt-24 pb-40">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
           <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
             <defs>
               <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                 <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5"/>
               </pattern>
             </defs>
             <rect width="100" height="100" fill="url(#grid)" />
           </svg>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center">
          <span className="inline-block px-4 py-2 mb-8 text-sm font-bold tracking-widest uppercase text-indigo-700 bg-indigo-50 rounded-full">
             <i className="ti-bolt mr-2"></i> World-Class Performance Hosting
          </span>
          <h1 className="text-6xl md:text-8xl font-black tracking-tight mb-8 leading-[1.1] font-poppins">
            Empower Your <span className="gradient-text">Online Vision.</span>
          </h1>
          <p className="max-w-3xl mx-auto text-xl text-gray-600 mb-12 font-medium">
            Next-generation cloud infrastructure built for speed, security, and global scale. Join 50,000+ creators who trust CloudHost.
          </p>

          <div className="max-w-5xl mx-auto bg-white p-3 rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] border border-gray-100 flex flex-col md:flex-row gap-3">
            <div className="flex-1 flex items-center px-6 gap-4">
              <Globe className="text-gray-400 w-6 h-6" />
              <input 
                type="text" 
                placeholder="Find your perfect domain name..." 
                className="w-full py-5 text-gray-800 placeholder-gray-400 border-none focus:ring-0 text-xl font-semibold outline-none"
              />
            </div>
            <button className="gradient-bg text-white px-12 py-5 rounded-[2rem] font-black text-xl hover:shadow-2xl transition-all flex items-center justify-center gap-2 group">
              Check Now <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </button>
          </div>

          <div className="mt-12 flex flex-wrap justify-center gap-8 text-sm font-bold text-gray-500 uppercase tracking-widest">
            <span className="flex items-center gap-2"><i className="fa-solid fa-circle-check text-green-500"></i> .com $8.99</span>
            <span className="flex items-center gap-2"><i className="fa-solid fa-circle-check text-green-500"></i> .net $10.99</span>
            <span className="flex items-center gap-2"><i className="fa-solid fa-circle-check text-green-500"></i> .io $24.99</span>
            <span className="flex items-center gap-2"><i className="fa-solid fa-circle-check text-green-500"></i> .me $5.99</span>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <div className="bg-white border-y border-gray-100 py-10">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-center items-center gap-12 opacity-60 hover:opacity-100 transition-all">
          <img src="https://upload.wikimedia.org/wikipedia/commons/9/93/Google_2015_logo.svg" className="h-8" alt="Google" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/0/0e/Microsoft_logo_%282012%29.svg" className="h-8" alt="Microsoft" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg" className="h-8" alt="Salesforce" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/4/4a/Amazon_icon.svg" className="h-8" alt="Amazon" />
        </div>
      </div>

      {/* Main Features */}
      <section className="py-32 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-end justify-between mb-20 gap-8">
            <div className="max-w-2xl text-left rtl:text-right">
              <h2 className="text-4xl md:text-5xl font-black mb-6 font-poppins">Built for performance, <br/> crafted for reliability.</h2>
              <p className="text-lg text-gray-600 leading-relaxed">We don't just provide space on a server. We provide a comprehensive ecosystem for your digital growth and peace of mind.</p>
            </div>
            <button className="group flex items-center gap-3 text-indigo-600 font-black text-lg">
              View All Features <div className="bg-indigo-600 text-white p-2 rounded-full group-hover:px-4 transition-all"><ArrowRight className="w-5 h-5" /></div>
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {FEATURES.map((feature, idx) => (
              <div key={idx} className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-2xl transition-all group hover:-translate-y-2">
                <div className="bg-indigo-50 text-indigo-600 w-16 h-16 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* NEW RE-USABLE SECTIONS DEMO */}
      <ContentSection 
        title="Scalable Infrastructure for Modern Apps"
        tagline="Next Gen Performance"
        description="Launch your projects on our state-of-the-art server network. We utilize the latest NVMe storage and high-bandwidth ports to ensure your users never wait for a page to load."
        image="https://i.ibb.co/zgpLksT/feature-new-1.jpg"
        features={['Instant Deployment', 'Root Access Included', 'Scalable Resources', 'DDoS Protection']}
        ctaText="Explore Solutions"
        stats={[
           { label: 'Uptime', value: '99.9%' },
           { label: 'Servers', value: '2,500+' },
           { label: 'Latency', value: '15ms' }
        ]}
      />

      <ContentSection 
        title="Industrial Grade Security at Every Layer"
        tagline="Peace of Mind"
        description="Security isn't an afterthought—it's at the core of our platform. From real-time monitoring to automated patches, we keep your digital assets safe 24/7/365."
        image="https://i.ibb.co/zgpLksT/feature-new-1.jpg"
        imageLeft={true}
        features={['AI Threat Detection', 'Automated Backups', 'Dedicated Firewalls', '2FA Authentication']}
        ctaText="Get Secured"
        bgGray={true}
      />

      {/* Testimonials Carousel */}
      <TestimonialSlider />

      {/* Dynamic CTA */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="gradient-bg rounded-[3.5rem] p-12 md:p-20 text-white flex flex-col lg:flex-row items-center gap-16 overflow-hidden relative shadow-[0_50px_100px_-20px_rgba(79,70,229,0.3)]">
            <div className="absolute top-0 right-0 opacity-10">
              <Cloud className="w-96 h-96 -translate-y-20 translate-x-20" />
            </div>
            <div className="flex-1 relative z-10">
              <h2 className="text-4xl md:text-6xl font-black mb-8 leading-tight font-poppins">Migrate your site <br/> for free today.</h2>
              <p className="text-xl opacity-90 mb-10 max-w-lg">Our expert migration team will move your entire website from your old host at no extra cost. Zero downtime, zero stress.</p>
              <div className="flex gap-4">
                 <button className="bg-white text-indigo-700 px-10 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-all shadow-xl">Start Migration</button>
              </div>
            </div>
            <div className="lg:w-1/3 relative z-10 hidden lg:block">
              <div className="bg-white/10 backdrop-blur-md p-8 rounded-[2.5rem] border border-white/20">
                <div className="flex items-center gap-4 mb-6">
                   <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
                   <span className="font-black text-sm uppercase tracking-widest">Specialist Online</span>
                </div>
                <p className="text-lg font-medium mb-6">"Average migration time for a WordPress site is under 45 minutes with zero data loss."</p>
                <div className="flex -space-x-4">
                  <img src=" https://i.ibb.co/zgpLksT/feature-new-1.jpg" className="w-12 h-12 rounded-full border-4 border-white/20" />
                  <img src=" https://i.ibb.co/zgpLksT/feature-new-1.jpg" className="w-12 h-12 rounded-full border-4 border-white/20" />
                  <img src=" https://i.ibb.co/zgpLksT/feature-new-1.jpg" className="w-12 h-12 rounded-full border-4 border-white/20" />
                  <div className="w-12 h-12 rounded-full bg-indigo-500 border-4 border-white/20 flex items-center justify-center text-xs font-bold">+12</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats and Logos */}
      <section className="py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 text-center">
           <h2 className="text-3xl font-black mb-20 uppercase tracking-[0.2em] text-gray-400 font-poppins">Trusted by Global Leaders</h2>
           <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
             <div className="bg-white p-12 rounded-[2.5rem] shadow-sm border border-gray-100 group hover:border-indigo-600 transition-colors">
               <div className="text-5xl font-black text-indigo-600 mb-4 group-hover:scale-110 transition-transform">50k+</div>
               <div className="text-gray-500 font-black uppercase tracking-widest text-xs">Customers</div>
             </div>
             <div className="bg-white p-12 rounded-[2.5rem] shadow-sm border border-gray-100 group hover:border-indigo-600 transition-colors">
               <div className="text-5xl font-black text-indigo-600 mb-4 group-hover:scale-110 transition-transform">150+</div>
               <div className="text-gray-500 font-black uppercase tracking-widest text-xs">Countries</div>
             </div>
             <div className="bg-white p-12 rounded-[2.5rem] shadow-sm border border-gray-100 group hover:border-indigo-600 transition-colors">
               <div className="text-5xl font-black text-indigo-600 mb-4 group-hover:scale-110 transition-transform">24/7</div>
               <div className="text-gray-500 font-black uppercase tracking-widest text-xs">Live Ops</div>
             </div>
             <div className="bg-white p-12 rounded-[2.5rem] shadow-sm border border-gray-100 group hover:border-indigo-600 transition-colors">
               <div className="text-5xl font-black text-indigo-600 mb-4 group-hover:scale-110 transition-transform">100%</div>
               <div className="text-gray-500 font-black uppercase tracking-widest text-xs">Carbon Neutral</div>
             </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default Home;