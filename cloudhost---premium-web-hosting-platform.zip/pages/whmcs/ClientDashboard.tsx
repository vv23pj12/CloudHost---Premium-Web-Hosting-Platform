
import React from 'react';
import { Server, CreditCard, MessageSquare, PlusCircle, ExternalLink, ShieldCheck, Activity, Globe, Package, ArrowRight } from 'lucide-react';
import { Page } from '../../types';

interface ClientDashboardProps {
  setCurrentPage: (p: Page) => void;
}

const ClientDashboard: React.FC<ClientDashboardProps> = ({ setCurrentPage }) => {
  const stats = [
    { label: 'Services', value: '3', icon: <Server className="text-blue-600" />, color: 'bg-blue-50' },
    { label: 'Domains', value: '1', icon: <Globe className="text-green-600" />, color: 'bg-green-50' },
    { label: 'Unpaid Invoices', value: '$0.00', icon: <CreditCard className="text-red-600" />, color: 'bg-red-50' },
    { label: 'Support Tickets', value: '0', icon: <MessageSquare className="text-purple-600" />, color: 'bg-purple-50' },
  ];

  const activeServices = [
    { name: 'Business Shared Hosting', domain: 'mywebsite.com', status: 'Active', renewal: 'Jan 15, 2025' },
    { name: 'Cloud VPS - Standard', domain: 'api.mywebsite.com', status: 'Active', renewal: 'Feb 10, 2025' },
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      {/* Dashboard Header */}
      <div className="bg-white border-b border-gray-100 py-12 mb-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
          <div>
            <h1 className="text-4xl font-black text-gray-900 font-poppins mb-2">Welcome Back, John!</h1>
            <p className="text-gray-500 font-medium italic">"Your infrastructure is currently running at 100% capacity."</p>
          </div>
          <div className="flex gap-4">
             <button className="bg-gray-100 text-gray-700 px-6 py-3 rounded-xl font-bold hover:bg-gray-200 transition-all flex items-center gap-2">
                <PlusCircle className="w-5 h-5" /> New Service
             </button>
             <button className="gradient-bg text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-indigo-100 flex items-center gap-2">
                Manage Billing
             </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
              <div className={`${stat.color} w-12 h-12 rounded-2xl flex items-center justify-center mb-4`}>
                {stat.icon}
              </div>
              <div className="text-3xl font-black text-gray-900 mb-1">{stat.value}</div>
              <div className="text-xs font-black text-gray-400 uppercase tracking-widest">{stat.label}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Active Services List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden">
               <div className="p-8 border-b border-gray-50 flex justify-between items-center">
                  <h3 className="text-xl font-black font-poppins flex items-center gap-3">
                    <Package className="text-indigo-600" /> Your Active Services
                  </h3>
                  <button className="text-indigo-600 font-bold text-sm hover:underline">View All</button>
               </div>
               <div className="divide-y divide-gray-50">
                  {activeServices.map((service, idx) => (
                    <div key={idx} className="p-8 flex flex-col md:flex-row justify-between items-center gap-4 hover:bg-gray-50/50 transition-colors">
                      <div>
                         <p className="font-black text-gray-900 text-lg leading-none mb-1">{service.name}</p>
                         <p className="text-indigo-600 text-sm font-bold flex items-center gap-1">
                           {service.domain} <ExternalLink className="w-3 h-3" />
                         </p>
                      </div>
                      <div className="flex items-center gap-8">
                         <div className="text-right">
                            <p className="text-xs font-black text-gray-400 uppercase">Renewal</p>
                            <p className="font-bold text-sm">{service.renewal}</p>
                         </div>
                         <div className="bg-green-100 text-green-700 px-4 py-1.5 rounded-full text-xs font-black uppercase">
                            {service.status}
                         </div>
                         <button className="bg-white border border-gray-200 p-2.5 rounded-xl text-gray-400 hover:text-indigo-600 transition-all">
                            <Activity className="w-5 h-5" />
                         </button>
                      </div>
                    </div>
                  ))}
               </div>
            </div>

            {/* Quick Actions Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               <div className="bg-indigo-600 p-8 rounded-[2rem] text-white group cursor-pointer hover:scale-[1.02] transition-all">
                  <Globe className="w-10 h-10 mb-6 opacity-80" />
                  <h4 className="text-xl font-black mb-2">Register Domain</h4>
                  <p className="text-indigo-100 text-sm mb-4">Find your next big idea online.</p>
                  <ArrowRight className="group-hover:translate-x-2 transition-transform" />
               </div>
               <div className="bg-gray-900 p-8 rounded-[2rem] text-white group cursor-pointer hover:scale-[1.02] transition-all">
                  <ShieldCheck className="w-10 h-10 mb-6 opacity-80" />
                  <h4 className="text-xl font-black mb-2">Security Audit</h4>
                  <p className="text-gray-400 text-sm mb-4">Check for vulnerabilities now.</p>
                  <ArrowRight className="group-hover:translate-x-2 transition-transform" />
               </div>
               <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm group cursor-pointer hover:scale-[1.02] transition-all">
                  <PlusCircle className="text-indigo-600 w-10 h-10 mb-6" />
                  <h4 className="text-xl font-black mb-2">Marketplace</h4>
                  <p className="text-gray-500 text-sm mb-4">Browse add-ons and licenses.</p>
                  <ArrowRight className="group-hover:translate-x-2 transition-transform text-indigo-600" />
               </div>
            </div>
          </div>

          {/* Sidebar Notifications / Support */}
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm">
               <h3 className="text-xl font-black font-poppins mb-6">Recent Activity</h3>
               <div className="space-y-6">
                  {[
                    { time: '2 hrs ago', msg: 'Successful Login from SF, US', type: 'security' },
                    { time: 'Yesterday', msg: 'Invoice #8822 paid successfully', type: 'billing' },
                    { time: '3 days ago', msg: 'Backup completed for VPS-01', type: 'system' }
                  ].map((act, i) => (
                    <div key={i} className="flex gap-4">
                       <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5 shrink-0"></div>
                       <div>
                          <p className="text-sm font-bold text-gray-800 leading-tight">{act.msg}</p>
                          <p className="text-xs text-gray-400 mt-1 uppercase font-black">{act.time}</p>
                       </div>
                    </div>
                  ))}
               </div>
            </div>

            <div className="gradient-bg p-8 rounded-[2rem] text-white text-center">
               <MessageSquare className="w-12 h-12 mx-auto mb-4" />
               <h3 className="text-xl font-black mb-2">Need Help?</h3>
               <p className="text-indigo-100 text-sm mb-6 leading-relaxed">Our support engineers are ready to assist you 24/7 with any query.</p>
               <button onClick={() => setCurrentPage('support-tickets')} className="w-full bg-white text-indigo-700 py-3 rounded-xl font-black hover:bg-indigo-50 transition-colors">
                  Open Support Ticket
               </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;
