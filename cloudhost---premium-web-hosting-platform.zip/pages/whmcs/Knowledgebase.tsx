
import React from 'react';
import { Search, Book, FileText, ChevronRight, Zap, Shield, CreditCard } from 'lucide-react';

const Knowledgebase: React.FC = () => {
  const categories = [
    { title: 'Getting Started', count: 12, icon: <Zap className="text-yellow-600" /> },
    { title: 'Hosting & Servers', count: 45, icon: <Book className="text-blue-600" /> },
    { title: 'Billing & Account', count: 18, icon: <CreditCard className="text-green-600" /> },
    { title: 'Security & SSL', count: 24, icon: <Shield className="text-red-600" /> },
  ];

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      <section className="bg-white py-24 border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-black mb-8 font-poppins">How can we <span className="text-indigo-600">help you?</span></h1>
          <div className="relative max-w-2xl mx-auto">
             <input 
                type="text" 
                placeholder="Search tutorials, troubleshooting guides..." 
                className="w-full pl-14 pr-6 py-5 bg-gray-50 border-2 border-transparent focus:border-indigo-600 focus:bg-white rounded-[2rem] text-lg transition-all outline-none font-medium"
             />
             <Search className="absolute left-6 top-5.5 text-gray-400 w-6 h-6" />
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 mt-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {categories.map((cat, i) => (
            <div key={i} className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all group cursor-pointer">
              <div className="bg-gray-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                {cat.icon}
              </div>
              <h3 className="text-xl font-black mb-2 font-poppins">{cat.title}</h3>
              <p className="text-gray-400 font-bold text-sm uppercase tracking-widest">{cat.count} Articles</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
             <h2 className="text-2xl font-black mb-8 font-poppins flex items-center gap-3">
                <FileText className="text-indigo-600" /> Popular Articles
             </h2>
             <div className="space-y-4">
                {[
                  'How to point your domain to CloudHost',
                  'Installing WordPress via cPanel',
                  'Managing your VPS with SSH',
                  'Setting up automated backups'
                ].map((article, i) => (
                  <div key={i} className="bg-white p-6 rounded-2xl border border-gray-50 flex justify-between items-center hover:bg-gray-50 transition-colors cursor-pointer group">
                    <span className="font-bold text-gray-700 group-hover:text-indigo-600 transition-colors">{article}</span>
                    <ChevronRight className="text-gray-300 w-5 h-5 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
                  </div>
                ))}
             </div>
          </div>
          <div>
             <h2 className="text-2xl font-black mb-8 font-poppins flex items-center gap-3">
                <Zap className="text-indigo-600" /> Recent Updates
             </h2>
             <div className="space-y-4">
                {[
                  'Updating PHP version on Shared Hosting',
                  'New DDoS protection layers explained',
                  'Billing cycle changes for 2025',
                  'Migrating from WHM to our Cloud Panel'
                ].map((article, i) => (
                  <div key={i} className="bg-white p-6 rounded-2xl border border-gray-50 flex justify-between items-center hover:bg-gray-50 transition-colors cursor-pointer group">
                    <span className="font-bold text-gray-700 group-hover:text-indigo-600 transition-colors">{article}</span>
                    <ChevronRight className="text-gray-300 w-5 h-5 group-hover:text-indigo-600 group-hover:translate-x-1 transition-all" />
                  </div>
                ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Knowledgebase;
