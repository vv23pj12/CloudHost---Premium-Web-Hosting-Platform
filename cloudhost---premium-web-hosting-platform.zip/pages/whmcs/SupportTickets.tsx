
import React, { useState } from 'react';
import { Send, Paperclip, MessageSquare, AlertCircle, CheckCircle } from 'lucide-react';

const SupportTickets: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="bg-slate-50 min-h-screen py-20">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-black mb-4 font-poppins">Open Support Ticket</h1>
          <p className="text-gray-600">Provide details about your issue and our technical team will respond shortly.</p>
        </div>

        {submitted ? (
          <div className="bg-white p-12 rounded-[3rem] text-center shadow-2xl border border-gray-100 animate-in zoom-in-95 duration-500">
             <div className="bg-green-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
                <CheckCircle className="text-green-600 w-12 h-12" />
             </div>
             <h2 className="text-3xl font-black mb-4 font-poppins">Ticket Created!</h2>
             <p className="text-gray-500 mb-10 text-lg">Your ticket ID is <strong>#CH-99210</strong>. You will receive an email notification when an agent replies.</p>
             <button onClick={() => setSubmitted(false)} className="bg-indigo-600 text-white px-10 py-4 rounded-2xl font-black text-lg hover:bg-indigo-700 transition-all">
                View My Tickets
             </button>
          </div>
        ) : (
          <div className="bg-white rounded-[3rem] shadow-xl border border-gray-100 overflow-hidden">
            <div className="bg-gray-900 p-8 text-white flex items-center gap-4">
               <div className="bg-indigo-600 p-3 rounded-2xl">
                  <MessageSquare className="w-6 h-6" />
               </div>
               <div>
                  <h3 className="text-xl font-black">Technical Support</h3>
                  <p className="text-gray-400 text-sm font-medium uppercase tracking-widest">Average Response: 15 Minutes</p>
               </div>
            </div>
            
            <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="p-10 space-y-8">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                     <label className="block text-sm font-black text-gray-400 uppercase tracking-widest mb-3">Service / Department</label>
                     <select className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl outline-none focus:border-indigo-600 focus:bg-white transition-all font-bold">
                        <option>Technical Assistance</option>
                        <option>Billing & Sales</option>
                        <option>Security & Compliance</option>
                        <option>General Inquiry</option>
                     </select>
                  </div>
                  <div>
                     <label className="block text-sm font-black text-gray-400 uppercase tracking-widest mb-3">Priority Level</label>
                     <select className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl outline-none focus:border-indigo-600 focus:bg-white transition-all font-bold">
                        <option>Normal - No Rush</option>
                        <option>Medium - Performance Issue</option>
                        <option>High - Website Down</option>
                        <option>Critical - Infrastructure Outage</option>
                     </select>
                  </div>
               </div>

               <div>
                  <label className="block text-sm font-black text-gray-400 uppercase tracking-widest mb-3">Subject Line</label>
                  <input 
                    type="text" 
                    placeholder="Brief summary of the issue..."
                    className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl outline-none focus:border-indigo-600 focus:bg-white transition-all font-bold"
                  />
               </div>

               <div>
                  <label className="block text-sm font-black text-gray-400 uppercase tracking-widest mb-3">Detailed Description</label>
                  <textarea 
                    rows={8}
                    placeholder="Please provide steps to reproduce, error messages, or account details..."
                    className="w-full px-6 py-4 bg-gray-50 border-2 border-gray-100 rounded-2xl outline-none focus:border-indigo-600 focus:bg-white transition-all font-bold resize-none"
                  ></textarea>
               </div>

               <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-4">
                  <button type="button" className="flex items-center gap-2 text-gray-500 font-bold hover:text-indigo-600 transition-colors">
                     <Paperclip className="w-5 h-5" /> Attach Files (Log, Screenshot)
                  </button>
                  <button type="submit" className="w-full md:w-auto bg-indigo-600 text-white px-12 py-5 rounded-2xl font-black text-xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 flex items-center justify-center gap-3">
                     Open Ticket <Send className="w-5 h-5" />
                  </button>
               </div>

               <div className="bg-indigo-50 p-6 rounded-2xl flex gap-4">
                  <AlertCircle className="text-indigo-600 shrink-0" />
                  <p className="text-sm text-indigo-800 font-medium">
                     Please ensure you have checked our <button className="font-black underline">Knowledgebase</button> for common issues before submitting a ticket. It might save you time!
                  </p>
               </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default SupportTickets;
