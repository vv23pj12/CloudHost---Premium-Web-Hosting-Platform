
import React from 'react';
import { Cloud, Cpu, Database, Server, Zap, Globe, ArrowRight } from 'lucide-react';

const CloudVPS: React.FC = () => {
  const vpsPlans = [
    { cpu: '1 vCPU', ram: '2 GB', storage: '40 GB NVMe', bandwidth: '1 TB', price: '$5.99' },
    { cpu: '2 vCPU', ram: '4 GB', storage: '80 GB NVMe', bandwidth: '2 TB', price: '$12.99', popular: true },
    { cpu: '4 vCPU', ram: '8 GB', storage: '160 GB NVMe', bandwidth: '4 TB', price: '$24.99' },
    { cpu: '8 vCPU', ram: '16 GB', storage: '320 GB NVMe', bandwidth: '8 TB', price: '$49.99' },
  ];

  return (
    <div className="bg-white">
      <section className="bg-gray-900 py-32 text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
           <Cloud className="w-[800px] h-[800px] absolute -right-40 -top-40" />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <span className="text-indigo-400 font-bold uppercase tracking-widest text-sm mb-4 block">High Performance Infrastructure</span>
            <h1 className="text-5xl md:text-7xl font-black mb-8 font-poppins">Full Root Access <br/><span className="text-indigo-400">Cloud VPS Hosting.</span></h1>
            <p className="text-xl text-gray-400 mb-12">Scalable cloud servers with enterprise-grade NVMe SSD storage and industrial-grade security. Deploy your instance in under 60 seconds.</p>
            <div className="flex gap-4">
               <button className="bg-indigo-600 text-white px-10 py-5 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl">Deploy Server</button>
               <button className="bg-white/10 text-white px-10 py-5 rounded-2xl font-bold text-lg border border-white/20 hover:bg-white/20 transition-all">View All Plans</button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {vpsPlans.map((plan, i) => (
            <div key={i} className={`p-8 rounded-[2rem] border transition-all ${plan.popular ? 'border-indigo-500 bg-indigo-50/30' : 'border-gray-100 bg-white'} hover:shadow-xl`}>
              <h3 className="text-xl font-bold mb-6 font-poppins">VPS Plan {i + 1}</h3>
              <div className="space-y-4 mb-8">
                <div className="flex justify-between text-sm"><span className="text-gray-500">CPU</span><span className="font-bold">{plan.cpu}</span></div>
                <div className="flex justify-between text-sm"><span className="text-gray-500">RAM</span><span className="font-bold">{plan.ram}</span></div>
                <div className="flex justify-between text-sm"><span className="text-gray-500">NVMe SSD</span><span className="font-bold">{plan.storage}</span></div>
                <div className="flex justify-between text-sm"><span className="text-gray-500">Bandwidth</span><span className="font-bold">{plan.bandwidth}</span></div>
              </div>
              <div className="text-center mb-8">
                <span className="text-4xl font-black">{plan.price}</span>
                <span className="text-gray-500 text-sm">/mo</span>
              </div>
              <button className={`w-full py-4 rounded-xl font-bold transition-all ${plan.popular ? 'bg-indigo-600 text-white' : 'bg-gray-900 text-white hover:bg-gray-800'}`}>
                Configure Now
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
             <div>
                <h2 className="text-4xl font-black mb-8 font-poppins">Ultimate Control for Developers</h2>
                <div className="space-y-8">
                   <div className="flex gap-4">
                      <div className="bg-white p-3 rounded-xl shadow-sm h-fit"><Zap className="text-indigo-600" /></div>
                      <div>
                         <h4 className="font-bold mb-1">Scale Instantly</h4>
                         <p className="text-gray-600 text-sm">Upgrade your CPU, RAM, or storage with a single click without any downtime.</p>
                      </div>
                   </div>
                   <div className="flex gap-4">
                      <div className="bg-white p-3 rounded-xl shadow-sm h-fit"><Database className="text-indigo-600" /></div>
                      <div>
                         <h4 className="font-bold mb-1">DDoS Protection</h4>
                         <p className="text-gray-600 text-sm">Enterprise-grade filtering to mitigate even the largest volumetric attacks.</p>
                      </div>
                   </div>
                   <div className="flex gap-4">
                      <div className="bg-white p-3 rounded-xl shadow-sm h-fit"><Globe className="text-indigo-600" /></div>
                      <div>
                         <h4 className="font-bold mb-1">20 Global Locations</h4>
                         <p className="text-gray-600 text-sm">Launch your apps closer to your users for minimal latency across the globe.</p>
                      </div>
                   </div>
                </div>
             </div>
             <div className="bg-gray-900 p-8 rounded-[2.5rem] text-indigo-400 font-mono text-sm shadow-2xl relative">
                <div className="flex gap-2 mb-6">
                   <div className="w-3 h-3 rounded-full bg-red-500"></div>
                   <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                   <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <div className="space-y-2">
                   <p className="text-white">$ ssh root@vps-01-cloudhost.com</p>
                   <p>root@vps-01-cloudhost.com's password: *********</p>
                   <p className="text-green-400"># Welcome to CloudHost VPS!</p>
                   <p className="text-green-400"># System load: 0.08  |  Uptime: 450 days</p>
                   <p># apt update && apt upgrade -y</p>
                   <p>...</p>
                   <p className="text-white"># docker-compose up -d</p>
                   <p className="text-indigo-300">Container site_db Starting...</p>
                   <p className="text-indigo-300">Container site_web Starting...</p>
                   <p className="text-green-400"># Server successfully deployed!</p>
                </div>
                <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl text-gray-900 font-poppins font-bold">
                   Uptime 99.99%
                </div>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CloudVPS;
