
import React from 'react';
import { Briefcase, Heart, Rocket, Star, ArrowRight } from 'lucide-react';

const Careers: React.FC = () => {
  const jobs = [
    { title: 'Senior Cloud Engineer', location: 'Remote / SF', type: 'Full-Time', dept: 'Engineering' },
    { title: 'Infrastructure Security Architect', location: 'London / Hybrid', type: 'Full-Time', dept: 'Security' },
    { title: 'Technical Support Specialist', location: 'Global Remote', type: 'Full-Time', dept: 'Customer Success' },
    { title: 'Product Designer (UI/UX)', location: 'Remote', type: 'Full-Time', dept: 'Product' },
  ];

  return (
    <div className="bg-white min-h-screen">
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-7xl font-black mb-8 font-poppins">Join the <span className="gradient-text">Cloud Revolution.</span></h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">We're building the infrastructure of the future. Come help us empower millions of digital creators worldwide.</p>
          <div className="flex justify-center gap-4">
             <button className="bg-indigo-600 text-white px-10 py-5 rounded-2xl font-black text-lg shadow-xl">View Open Roles</button>
             <button className="bg-white text-gray-900 px-10 py-5 rounded-2xl font-black text-lg border border-gray-200 hover:bg-gray-50">Our Culture</button>
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
           <img src="https://picsum.photos/800/600?random=team" className="rounded-[3rem] shadow-2xl" />
           <div>
              <h2 className="text-4xl font-black mb-8 font-poppins">Why Work at CloudHost?</h2>
              <div className="space-y-8">
                 <div className="flex gap-6">
                    <div className="bg-red-50 p-4 rounded-2xl"><Heart className="text-red-500" /></div>
                    <div>
                       <h4 className="font-bold text-xl mb-1">Human-First Culture</h4>
                       <p className="text-gray-600">We prioritize well-being, growth, and inclusion. Work from anywhere, thrive everywhere.</p>
                    </div>
                 </div>
                 <div className="flex gap-6">
                    <div className="bg-blue-50 p-4 rounded-2xl"><Rocket className="text-blue-500" /></div>
                    <div>
                       <h4 className="font-bold text-xl mb-1">Impactful Work</h4>
                       <p className="text-gray-600">Your code and contributions will power the websites of startups, nonprofits, and tech giants.</p>
                    </div>
                 </div>
                 <div className="flex gap-6">
                    <div className="bg-yellow-50 p-4 rounded-2xl"><Star className="text-yellow-600" /></div>
                    <div>
                       <h4 className="font-bold text-xl mb-1">Unbeatable Perks</h4>
                       <p className="text-gray-600">Competitive salaries, equity, home-office stipends, and unlimited learning budget.</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>

        <div className="bg-gray-900 rounded-[3rem] p-12 md:p-20 text-white">
           <h2 className="text-4xl font-black mb-12 font-poppins text-center">Open Opportunities</h2>
           <div className="space-y-4">
              {jobs.map((job, i) => (
                <div key={i} className="flex flex-col md:flex-row items-center justify-between p-8 bg-white/5 border border-white/10 rounded-3xl hover:bg-white/10 transition-all group">
                   <div className="text-center md:text-left mb-4 md:mb-0">
                      <p className="text-indigo-400 font-bold text-sm uppercase tracking-widest mb-1">{job.dept}</p>
                      <h4 className="text-2xl font-bold">{job.title}</h4>
                      <p className="text-gray-400 text-sm mt-1">{job.location} • {job.type}</p>
                   </div>
                   <button className="bg-white text-gray-900 px-8 py-4 rounded-2xl font-bold group-hover:bg-indigo-500 group-hover:text-white transition-all flex items-center gap-2">
                      Apply Now <ArrowRight className="w-5 h-5" />
                   </button>
                </div>
              ))}
           </div>
           <p className="mt-12 text-center text-gray-400">Don't see a role that fits? <button className="text-indigo-400 font-bold hover:underline">Send us an open application.</button></p>
        </div>
      </section>
    </div>
  );
};

export default Careers;
