
import React from 'react';
import { DollarSign, Users, Award, TrendingUp, CheckCircle2 } from 'lucide-react';

const Affiliate: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <section className="bg-indigo-600 py-32 text-white text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-5xl md:text-7xl font-black mb-8 font-poppins">Earn Big with <br/> CloudHost Affiliates.</h1>
          <p className="text-xl text-indigo-100 mb-12">Earn up to $150 for every referral. Join the highest-paying affiliate program in the hosting industry today.</p>
          <button className="bg-white text-indigo-600 px-12 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-all shadow-xl">Start Earning Now</button>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-black mb-4 font-poppins">How It Works</h2>
          <p className="text-gray-600">Three simple steps to start earning passive income.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="text-center">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-8 text-3xl font-black">1</div>
            <h3 className="text-2xl font-bold mb-4 font-poppins">Sign Up</h3>
            <p className="text-gray-600">Register for free and get access to your personalized affiliate dashboard and marketing assets.</p>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-8 text-3xl font-black">2</div>
            <h3 className="text-2xl font-bold mb-4 font-poppins">Promote</h3>
            <p className="text-gray-600">Share your unique link on your blog, social media, or website using our professional banners.</p>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-8 text-3xl font-black">3</div>
            <h3 className="text-2xl font-bold mb-4 font-poppins">Get Paid</h3>
            <p className="text-gray-600">Earn high commissions for every successful signup. Payments are sent monthly via PayPal or Wire.</p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="bg-white rounded-[3rem] p-12 md:p-20 shadow-xl border border-gray-100">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <div>
                   <h2 className="text-4xl font-black mb-8 font-poppins">Why Join Our Program?</h2>
                   <div className="space-y-6">
                      <div className="flex gap-4">
                         <CheckCircle2 className="text-green-500 shrink-0" />
                         <p className="font-bold">High Commission Rates: Up to $150 per sale</p>
                      </div>
                      <div className="flex gap-4">
                         <CheckCircle2 className="text-green-500 shrink-0" />
                         <p className="font-bold">90-Day Cookie Life: Get credit for late signups</p>
                      </div>
                      <div className="flex gap-4">
                         <CheckCircle2 className="text-green-500 shrink-0" />
                         <p className="font-bold">Unlimited Earnings: No cap on how much you can earn</p>
                      </div>
                      <div className="flex gap-4">
                         <CheckCircle2 className="text-green-500 shrink-0" />
                         <p className="font-bold">Real-time Tracking: Monitor your clicks and sales live</p>
                      </div>
                   </div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                   <div className="bg-indigo-600 p-10 rounded-3xl text-white text-center">
                      <DollarSign className="w-12 h-12 mx-auto mb-4" />
                      <p className="text-3xl font-black">$1M+</p>
                      <p className="text-xs font-bold opacity-80 uppercase tracking-widest">Paid Yearly</p>
                   </div>
                   <div className="bg-gray-900 p-10 rounded-3xl text-white text-center">
                      <Users className="w-12 h-12 mx-auto mb-4" />
                      <p className="text-3xl font-black">10k+</p>
                      <p className="text-xs font-bold opacity-80 uppercase tracking-widest">Affiliates</p>
                   </div>
                   <div className="bg-gray-100 p-10 rounded-3xl text-gray-900 text-center">
                      <Award className="w-12 h-12 mx-auto mb-4 text-indigo-600" />
                      <p className="text-3xl font-black">#1</p>
                      <p className="text-xs font-bold opacity-60 uppercase tracking-widest">Ranked Program</p>
                   </div>
                   <div className="bg-indigo-50 p-10 rounded-3xl text-indigo-600 text-center">
                      <TrendingUp className="w-12 h-12 mx-auto mb-4" />
                      <p className="text-3xl font-black">45%</p>
                      <p className="text-xs font-bold opacity-80 uppercase tracking-widest">Conv. Rate</p>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Affiliate;
