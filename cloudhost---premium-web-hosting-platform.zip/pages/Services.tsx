
import React from 'react';
import { Server, Cpu, Database, Cloud, Shield, Globe } from 'lucide-react';

const Services: React.FC = () => {
  const serviceList = [
    {
      title: 'Shared Hosting',
      icon: <Server className="w-8 h-8 text-indigo-600" />,
      desc: 'Affordable and reliable hosting for individual creators and small businesses. Includes cPanel, one-click installers, and free SSL.',
      features: ['One-click WordPress', 'Free Migration', '99.9% Uptime']
    },
    {
      title: 'Cloud VPS',
      icon: <Cloud className="w-8 h-8 text-indigo-600" />,
      desc: 'Scale your resources on demand. Get dedicated power with the flexibility of the cloud. Root access included.',
      features: ['Scalable RAM/CPU', 'Instant Deployment', 'Snapshot Backups']
    },
    {
      title: 'Dedicated Servers',
      icon: <Cpu className="w-8 h-8 text-indigo-600" />,
      desc: 'Ultimate performance for heavy workloads. Your own enterprise-grade hardware with 100% dedicated resources.',
      features: ['AMD EPYC™ CPUs', 'Enterprise NVMe', 'Private Network']
    },
    {
      title: 'Email Hosting',
      icon: <Shield className="w-8 h-8 text-indigo-600" />,
      desc: 'Professional @yourcompany.com email addresses. Secure, ad-free, and accessible from anywhere.',
      features: ['Anti-spam Protection', 'IMAP/POP3/SMTP', 'Large Storage']
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen">
      <div className="bg-indigo-600 py-20 text-white text-center">
        <h1 className="text-4xl font-bold mb-4">Our Services</h1>
        <p className="text-indigo-100 max-w-2xl mx-auto px-4">Enterprise-grade hosting solutions for projects of every size.</p>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {serviceList.map((service, idx) => (
            <div key={idx} className="bg-white p-10 rounded-3xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-8 hover:shadow-xl transition-shadow">
              <div className="bg-indigo-50 w-20 h-20 rounded-2xl flex items-center justify-center shrink-0">
                {service.icon}
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-4">{service.title}</h2>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.desc}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {service.features.map((f, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm font-medium text-gray-700">
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full" />
                      {f}
                    </div>
                  ))}
                </div>
                <button className="mt-8 text-indigo-600 font-bold hover:underline flex items-center gap-2">
                  Learn More <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;
