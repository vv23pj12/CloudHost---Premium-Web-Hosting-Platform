import React from 'react';
import { Terminal, CheckCircle2, Zap, Shield, Mail, Database, Rocket, Layout, Globe, ArrowRight } from 'lucide-react';
import ContentSection from '../components/ContentSection';

const CPanelHosting: React.FC = () => {
  const plans = [
    {
      name: 'Starter cPanel',
      price: '$3.49',
      desc: 'Optimized for personal websites and simple blogs.',
      features: ['1 Domain', '20 GB NVMe Storage', 'Unlimited Bandwidth', 'Free cPanel License', 'Free SSL Certificate', 'JetBackup Included']
    },
    {
      name: 'Advanced cPanel',
      price: '$6.99',
      desc: 'The choice of professionals for medium business sites.',
      features: ['Unlimited Domains', '100 GB NVMe Storage', 'Unlimited Bandwidth', '2X Server Resources', 'Free Domain Name', 'Softaculous 1-Click'],
      popular: true
    },
    {
      name: 'Turbo cPanel',
      price: '$12.99',
      desc: 'Maximum performance with LiteSpeed & Turbo caching.',
      features: ['Unlimited Domains', 'Unlimited NVMe Storage', 'Unlimited Bandwidth', '5X Server Resources', 'LiteSpeed Web Server', 'Priority Support']
    }
  ];

  const tools = [
    { title: 'Softaculous', desc: 'Install 400+ apps like WordPress, Joomla, and Magento in a single click.', icon: <Rocket className="w-8 h-8" /> },
    { title: 'File Manager', desc: 'Powerful web-based file management without needing an external FTP client.', icon: <Layout className="w-8 h-8" /> },
    { title: 'Email Wizard', desc: 'Easily set up professional email addresses and anti-spam filters.', icon: <Mail className="w-8 h-8" /> },
    { title: 'Database Pro', desc: 'Manage MySQL and PostgreSQL databases effortlessly via phpMyAdmin.', icon: <Database className="w-8 h-8" /> },
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gray-900 py-32 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-indigo-500/20 via-transparent to-transparent"></div>
          <Terminal className="w-[600px] h-[600px] absolute -right-40 -top-20 opacity-20" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Terminal className="w-6 h-6" />
              </div>
              <span className="text-indigo-400 font-black uppercase tracking-[0.2em] text-sm">Industry Standard Control</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 font-poppins leading-tight">
              Powerful cPanel <br/> <span className="text-indigo-400">Hosting Solutions.</span>
            </h1>
            <p className="text-xl text-gray-400 mb-10 leading-relaxed">
              Experience the world's most popular hosting control panel. Simple enough for beginners, yet powerful enough for advanced sysadmins. Optimized for WordPress and PHP.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="gradient-bg text-white px-10 py-5 rounded-2xl font-black text-lg hover:scale-105 transition-all shadow-xl shadow-indigo-500/20">
                View Plans
              </button>
              <button className="bg-white/10 text-white border border-white/20 px-10 py-5 rounded-2xl font-black text-lg hover:bg-white/20 transition-all">
                cPanel Demo
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Grid */}
      <section className="py-24 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-black mb-6 font-poppins">Straightforward Pricing</h2>
            <p className="text-gray-500 max-w-2xl mx-auto font-medium">Choose the plan that fits your growth. All plans include the latest version of cPanel and 24/7 technical monitoring.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, i) => (
              <div key={i} className={`bg-white p-10 rounded-[3rem] border transition-all hover:-translate-y-2 ${plan.popular ? 'border-indigo-600 shadow-2xl relative' : 'border-gray-100 shadow-sm'}`}>
                {plan.popular && (
                  <span className="absolute top-0 right-10 -translate-y-1/2 bg-indigo-600 text-white px-6 py-2 rounded-full text-xs font-black tracking-widest uppercase">
                    Most Popular
                  </span>
                )}
                <h3 className="text-2xl font-black mb-2 font-poppins">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-5xl font-black text-gray-900">{plan.price}</span>
                  <span className="text-gray-400 font-bold">/mo</span>
                </div>
                <p className="text-gray-500 text-sm mb-8 leading-relaxed font-medium">{plan.desc}</p>
                <ul className="space-y-4 mb-10 border-t border-gray-50 pt-8">
                  {plan.features.map((f, idx) => (
                    <li key={idx} className="flex items-center gap-3 text-sm font-bold text-gray-700">
                      <CheckCircle2 className="w-5 h-5 text-indigo-500 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button className={`w-full py-5 rounded-2xl font-black text-lg transition-all ${plan.popular ? 'gradient-bg text-white shadow-xl' : 'bg-gray-100 text-gray-900 hover:bg-gray-200'}`}>
                  Choose {plan.name}
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-32 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="relative group">
               <div className="absolute -inset-4 bg-indigo-50 rounded-[3rem] rotate-3 group-hover:rotate-0 transition-transform"></div>
               <img 
                src="https://i.ibb.co/zgpLksT/feature-new-1.jpg" 
                alt="cPanel Interface" 
                className="relative rounded-[2.5rem] shadow-2xl z-10 border-8 border-white"
               />
               <div className="absolute -bottom-6 -right-6 bg-white p-8 rounded-3xl shadow-2xl z-20 border border-gray-50 max-w-[250px] hidden md:block">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center text-white">
                      <Shield className="w-6 h-6" />
                    </div>
                    <span className="font-black text-gray-900">Secure Panel</span>
                  </div>
                  <p className="text-xs text-gray-500 font-bold leading-relaxed">256-bit SSL encryption on every cPanel access point for maximum security.</p>
               </div>
            </div>

            <div>
              <span className="text-indigo-600 font-black uppercase tracking-[0.2em] text-sm mb-4 block">Simplified Management</span>
              <h2 className="text-4xl md:text-5xl font-black mb-10 font-poppins leading-tight">Master your website <br/> without any code.</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                {tools.map((tool, i) => (
                  <div key={i} className="space-y-4">
                    <div className="text-indigo-600 bg-indigo-50 w-14 h-14 rounded-2xl flex items-center justify-center">
                      {tool.icon}
                    </div>
                    <h4 className="text-xl font-black text-gray-900">{tool.title}</h4>
                    <p className="text-sm text-gray-600 leading-relaxed font-medium">{tool.desc}</p>
                  </div>
                ))}
              </div>
              <button className="mt-12 flex items-center gap-3 text-indigo-600 font-black text-lg group">
                Explore All Tools <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & Performance */}
      <ContentSection 
        title="Industrial Grade Speed for cPanel Users"
        tagline="Performance Optimized"
        description="Our cPanel nodes are limited to a small number of users per CPU core. Combined with NVMe SSDs and LiteSpeed servers, your site will load up to 20x faster than traditional hosting."
        image="https://picsum.photos/1000/800?random=cpanel-speed"
        imageLeft={true}
        features={['NVMe Storage', 'LiteSpeed Web Server', 'QUIC.cloud CDN', 'DDR5 ECC RAM']}
        ctaText="See the Speed"
        bgGray={true}
      />

      {/* Integration Banner */}
      <section className="py-24 bg-indigo-600 text-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex justify-center gap-12 flex-wrap opacity-50 mb-16 grayscale brightness-0 invert">
            <img src="https://upload.wikimedia.org/wikipedia/commons/9/93/Google_2015_logo.svg" className="h-8" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/0/0e/Microsoft_logo_%282012%29.svg" className="h-8" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/f/f9/Salesforce.com_logo.svg" className="h-8" />
          </div>
          <h2 className="text-4xl md:text-6xl font-black mb-8 font-poppins">Ready to take control?</h2>
          <p className="text-xl text-indigo-100 mb-12 max-w-2xl mx-auto">Join thousands of businesses who have simplified their workflow with our premium cPanel hosting.</p>
          <button className="bg-white text-indigo-600 px-12 py-5 rounded-2xl font-black text-xl hover:scale-105 transition-all shadow-2xl">
            Get Started Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default CPanelHosting;