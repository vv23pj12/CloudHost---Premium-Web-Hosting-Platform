
import React from 'react';
import { ArrowLeft, MessageCircle, Share2, Facebook, Twitter, Linkedin } from 'lucide-react';
import { Page } from '../types';

interface BlogPostProps {
  setCurrentPage: (p: Page) => void;
}

const BlogPost: React.FC<BlogPostProps> = ({ setCurrentPage }) => {
  return (
    <div className="bg-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-16">
        <button 
          onClick={() => setCurrentPage('blog')}
          className="flex items-center gap-2 text-gray-500 hover:text-indigo-600 mb-10 transition-colors font-semibold"
        >
          <ArrowLeft className="w-5 h-5" /> Back to Blog
        </button>

        <header className="mb-12">
          <span className="text-indigo-600 font-bold uppercase tracking-widest text-sm">Business Strategy</span>
          <h1 className="text-4xl md:text-5xl font-black text-gray-900 mt-4 mb-8 leading-tight">
            How to Choose the Right Hosting for Your Business
          </h1>
          <div className="flex items-center gap-4 py-6 border-y border-gray-100">
            <img src="https://picsum.photos/100/100?random=author" alt="Author" className="w-12 h-12 rounded-full" />
            <div className="flex-1">
              <p className="font-bold text-gray-900">Mark Veran</p>
              <p className="text-sm text-gray-500">Chief Technology Officer • Oct 12, 2024</p>
            </div>
            <div className="flex gap-2">
              <button className="p-2 text-gray-400 hover:text-indigo-600"><Facebook className="w-5 h-5" /></button>
              <button className="p-2 text-gray-400 hover:text-indigo-600"><Twitter className="w-5 h-5" /></button>
              <button className="p-2 text-gray-400 hover:text-indigo-600"><Linkedin className="w-5 h-5" /></button>
            </div>
          </div>
        </header>

        <div className="prose prose-lg prose-indigo max-w-none text-gray-700 leading-relaxed space-y-8">
          <p className="text-xl font-medium text-gray-600 italic border-l-4 border-indigo-600 pl-6">
            Choosing the right hosting plan is often the difference between a thriving online business and a frustrated user base. This guide simplifies the complex world of server infrastructure.
          </p>
          
          <img 
            src="https://picsum.photos/1200/600?random=post-inner" 
            alt="Server Room" 
            className="rounded-3xl shadow-xl w-full my-12" 
          />

          <h2 className="text-3xl font-bold text-gray-900">1. Assess Your Current Traffic</h2>
          <p>
            If you're just starting, shared hosting is usually more than enough. However, if you're expecting thousands of visitors a day, you'll want to look at VPS or Cloud Hosting solutions.
          </p>

          <h2 className="text-3xl font-bold text-gray-900">2. Technical Skill Level</h2>
          <p>
            Do you have a sysadmin on hand? If not, managed hosting is your best friend. It allows you to focus on your content while our team handles the heavy lifting of security updates and patches.
          </p>

          <div className="bg-indigo-50 p-8 rounded-3xl my-12">
            <h3 className="text-2xl font-bold text-indigo-900 mb-4">Pro Tip: Always Check Backups</h3>
            <p className="text-indigo-800">
              Never sign up for a hosting plan that doesn't include automated daily backups. It is the most important insurance policy for your digital assets.
            </p>
          </div>
        </div>

        <div className="mt-20 pt-12 border-t border-gray-100 flex justify-between items-center">
          <div className="flex items-center gap-2">
             <MessageCircle className="w-6 h-6 text-gray-400" />
             <span className="font-bold text-gray-800">12 Comments</span>
          </div>
          <button className="flex items-center gap-2 text-indigo-600 font-bold bg-indigo-50 px-6 py-3 rounded-2xl">
             <Share2 className="w-5 h-5" /> Share Post
          </button>
        </div>
      </div>
    </div>
  );
};

export default BlogPost;
