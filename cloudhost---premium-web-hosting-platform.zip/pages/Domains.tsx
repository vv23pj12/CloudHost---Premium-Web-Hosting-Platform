import React from 'react';
import { Search, Globe, CheckCircle, ShieldCheck, Zap } from 'lucide-react';
import { DOMAIN_EXTENSIONS } from '../constants.tsx';

const Domains: React.FC = () => {
  return (
    <div className="bg-slate-50 min-h-screen">
      <section className="gradient-bg py-24 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-black mb-8">Search for Your Perfect Domain</h1>
          <p className="text-xl mb-12 opacity-90">Find the right extension and start your journey online today.</p>
          
          <div className="bg-white p-2 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-2">
            <div className="flex-1 flex items-center px-6 gap-4">
              <Globe className="text-indigo-600 w-6 h-6" />
              <input 
                type="text" 
                placeholder="Type your business name here..." 
                className="w-full py-4 text-gray-900 text-lg border-none focus:ring-0 font-medium"
              />
            </div>
            <button className="bg-indigo-600 text-white px-10 py-4 rounded-xl font-bold text-xl hover:bg-indigo-700 transition-all shadow-lg">
              Check Availability
            </button>
          </div>

          <div className="mt-12 flex flex-wrap justify-center gap-8">
            {DOMAIN_EXTENSIONS.slice(0, 4).map((ext) => (
              <div key={ext.name} className="flex flex-col">
                <span className="text-2xl font-bold">{ext.name}</span>
                <span className="text-sm opacity-80">{ext.price}/yr</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {DOMAIN_EXTENSIONS.map((ext) => (
            <div key={ext.name} className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex justify-between items-center hover:shadow-xl transition-all group">
              <div>
                <span className="text-3xl font-black group-hover:text-indigo-600 transition-colors">{ext.name}</span>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-indigo-600 font-bold">{ext.price}</span>
                  <span className="text-gray-400 line-through text-sm">{ext.oldPrice}</span>
                </div>
              </div>
              <button className="bg-indigo-50 text-indigo-600 px-6 py-2 rounded-full font-bold hover:bg-indigo-600 hover:text-white transition-all">
                Register
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
          <div>
            <div className="bg-indigo-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Zap className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-xl font-bold mb-4">Instant Activation</h3>
            <p className="text-gray-600">Your domain is registered and active within seconds of purchase.</p>
          </div>
          <div>
            <div className="bg-green-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <ShieldCheck className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-bold mb-4">Privacy Protection</h3>
            <p className="text-gray-600">We offer WHOIS privacy to keep your personal info safe from spammers.</p>
          </div>
          <div>
            <div className="bg-blue-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold mb-4">Easy Management</h3>
            <p className="text-gray-600">Simple DNS management and one-click renewals from your dashboard.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Domains;