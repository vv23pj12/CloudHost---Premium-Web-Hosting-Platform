import React, { useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../constants.tsx';

const TestimonialSlider: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === TESTIMONIALS.length - 1 ? 0 : prev + 1));
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1));
  }, []);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [isAutoPlaying, nextSlide]);

  return (
    <section 
      className="py-24 bg-white overflow-hidden"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      <div className="max-w-7xl mx-auto px-4 relative">
        <div className="text-center mb-16">
          <span className="text-indigo-600 font-black uppercase tracking-[0.2em] text-sm mb-4 block">Success Stories</span>
          <h2 className="text-4xl md:text-5xl font-black text-gray-900 font-poppins">What our clients say</h2>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Background Decoration */}
          <Quote className="absolute -top-10 -left-10 w-32 h-32 text-indigo-50 opacity-50 -z-10 rotate-12" />
          
          {/* Slider Content */}
          <div className="relative bg-indigo-50/30 rounded-[3rem] p-8 md:p-16 border border-indigo-100/50">
            <div className="flex flex-col items-center text-center">
              <div className="mb-8">
                <img 
                  src={TESTIMONIALS[currentIndex].avatar} 
                  alt={TESTIMONIALS[currentIndex].name}
                  className="w-24 h-24 rounded-full border-4 border-white shadow-xl object-cover"
                />
              </div>
              
              <p className="text-xl md:text-3xl font-medium text-gray-800 leading-relaxed mb-10 font-poppins italic">
                "{TESTIMONIALS[currentIndex].content}"
              </p>
              
              <div>
                <h4 className="text-xl font-black text-gray-900">{TESTIMONIALS[currentIndex].name}</h4>
                <p className="text-indigo-600 font-bold text-sm uppercase tracking-widest mt-1">
                  {TESTIMONIALS[currentIndex].role}
                </p>
              </div>
            </div>

            {/* Navigation Arrows */}
            <div className="absolute top-1/2 -translate-y-1/2 -left-4 md:-left-8">
              <button 
                onClick={prevSlide}
                className="bg-white text-indigo-600 p-4 rounded-full shadow-xl hover:bg-indigo-600 hover:text-white transition-all focus:ring-4 focus:ring-indigo-100 outline-none"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            </div>
            <div className="absolute top-1/2 -translate-y-1/2 -right-4 md:-right-8">
              <button 
                onClick={nextSlide}
                className="bg-white text-indigo-600 p-4 rounded-full shadow-xl hover:bg-indigo-600 hover:text-white transition-all focus:ring-4 focus:ring-indigo-100 outline-none"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Pagination Dots */}
          <div className="flex justify-center gap-3 mt-10">
            {TESTIMONIALS.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  currentIndex === idx ? 'w-10 bg-indigo-600' : 'w-2.5 bg-indigo-200'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialSlider;