import React from 'react';
// Added Zap to the imports from lucide-react to fix the 'Cannot find name' error
import { ArrowRight, CheckCircle2, Zap } from 'lucide-react';

interface ContentSectionProps {
  title: string;
  tagline?: string;
  description: string;
  image: string;
  imageLeft?: boolean;
  features?: string[];
  ctaText?: string;
  stats?: { label: string; value: string }[];
  bgGray?: boolean;
}

const ContentSection: React.FC<ContentSectionProps> = ({
  title,
  tagline,
  description,
  image,
  imageLeft = false,
  features,
  ctaText,
  stats,
  bgGray = false,
}) => {
  return (
    <section className={`py-24 ${bgGray ? 'bg-slate-50' : 'bg-white'} overflow-hidden`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className={`flex flex-col lg:flex-row items-center gap-16 lg:gap-24 ${imageLeft ? 'lg:flex-row-reverse' : ''}`}>
          
          <div className="flex-1 space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
            {tagline && (
              <span className="text-indigo-600 font-black uppercase tracking-[0.2em] text-sm">
                {tagline}
              </span>
            )}
            <h2 className="text-4xl md:text-5xl font-black text-gray-900 leading-tight font-poppins">
              {title}
            </h2>
            <p className="text-lg text-gray-600 leading-relaxed max-w-xl">
              {description}
            </p>

            {features && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="bg-green-100 p-1 rounded-full shrink-0">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                    </div>
                    <span className="text-sm font-bold text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            )}

            {stats && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-8 pt-4">
                {stats.map((stat, i) => (
                  <div key={i}>
                    <div className="text-3xl font-black text-indigo-600 mb-1">{stat.value}</div>
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-widest">{stat.label}</div>
                  </div>
                ))}
              </div>
            )}

            {ctaText && (
              <button className="flex items-center gap-3 bg-gray-900 text-white px-10 py-4 rounded-2xl font-black text-lg hover:bg-indigo-600 transition-all shadow-xl group">
                {ctaText} <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
              </button>
            )}
          </div>

          <div className="flex-1 relative group">
            <div className="absolute -inset-4 bg-indigo-50 rounded-[3rem] -rotate-2 group-hover:rotate-0 transition-transform duration-500"></div>
            <img 
              src={image} 
              alt={title} 
              className="relative w-full rounded-[2.5rem] shadow-2xl z-10 transition-all duration-700 border-8 border-white" 
            />
            <div className="absolute -bottom-10 -right-10 bg-white p-6 rounded-3xl shadow-2xl z-20 hidden lg:block border border-gray-100">
               <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center text-white">
                     <Zap className="w-6 h-6" />
                  </div>
                  <div>
                     <p className="font-black text-gray-900 leading-none mb-1">99.9% Uptime</p>
                     <p className="text-xs font-bold text-gray-400">Guaranteed SLA</p>
                  </div>
               </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default ContentSection;