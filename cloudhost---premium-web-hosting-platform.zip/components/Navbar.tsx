import React, { useState } from 'react';
import { Menu, X, Cloud, Languages, Palette, ChevronDown, Server, Cpu, Database, Globe, Info, Phone, Users, Briefcase, Award, Zap, LifeBuoy, BookOpen, MessageSquare, Terminal } from 'lucide-react';
import { Page, ThemeColor } from '../types';

interface NavbarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  isRtl: boolean;
  setIsRtl: (val: boolean) => void;
  themeColor: ThemeColor;
  setThemeColor: (color: ThemeColor) => void;
}

const Navbar: React.FC<NavbarProps> = ({ 
  currentPage, 
  setCurrentPage, 
  isRtl, 
  setIsRtl, 
  themeColor, 
  setThemeColor 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeMegaMenu, setActiveMegaMenu] = useState<string | null>(null);

  const hostingItems = [
    { title: 'Shared Hosting', desc: 'Fast and easy for beginners', icon: <Server className="w-5 h-5" />, page: 'shared-hosting' as Page },
    { title: 'cPanel Hosting', desc: 'World #1 Control Panel', icon: <Terminal className="w-5 h-5" />, page: 'cpanel-hosting' as Page },
    { title: 'Cloud VPS', desc: 'Scalable cloud performance', icon: <Cloud className="w-5 h-5" />, page: 'cloud-vps' as Page },
    { title: 'Dedicated Servers', desc: 'raw power for enterprises', icon: <Cpu className="w-5 h-5" />, page: 'dedicated-servers' as Page },
    { title: 'Domain Names', desc: 'Find your perfect domain', icon: <Globe className="w-5 h-5" />, page: 'domains' as Page },
  ];

  const supportItems = [
    { title: 'Knowledgebase', desc: 'Tutorials and self-help', icon: <BookOpen className="w-5 h-5" />, page: 'knowledgebase' as Page },
    { title: 'Submit Ticket', desc: 'Get direct expert help', icon: <MessageSquare className="w-5 h-5" />, page: 'support-tickets' as Page },
    { title: 'Contact Us', desc: 'Talk to our team', icon: <Phone className="w-5 h-5" />, page: 'contact' as Page },
  ];

  const handleNavClick = (page: Page) => {
    setCurrentPage(page);
    setActiveMegaMenu(null);
    setIsOpen(false);
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-gray-100 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-2 cursor-pointer group" onClick={() => handleNavClick('home')}>
            <div className="gradient-bg p-2 rounded-xl text-white group-hover:rotate-12 transition-transform shadow-md shadow-indigo-100">
              <Cloud className="w-6 h-6" />
            </div>
            <span className="text-2xl font-black gradient-text tracking-tight">
              CloudHost
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center space-x-2 rtl:space-x-reverse">
            <button onClick={() => handleNavClick('home')} className={`px-4 py-2 text-sm font-bold transition-all ${currentPage === 'home' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'}`}>Home</button>
            
            {/* Hosting Mega Menu */}
            <div className="relative group/mega" onMouseEnter={() => setActiveMegaMenu('hosting')} onMouseLeave={() => setActiveMegaMenu(null)}>
              <button className={`flex items-center gap-1 px-4 py-2 text-sm font-bold transition-all ${activeMegaMenu === 'hosting' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'}`}>
                Hosting <ChevronDown className={`w-4 h-4 transition-transform ${activeMegaMenu === 'hosting' ? 'rotate-180' : ''}`} />
              </button>
              {activeMegaMenu === 'hosting' && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 pt-4 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="bg-white shadow-[0_20px_50px_rgba(0,0,0,0.1)] rounded-[2rem] border border-gray-100 p-8 w-[700px] grid grid-cols-2 gap-4">
                    {hostingItems.map((item) => (
                      <button key={item.page} onClick={() => handleNavClick(item.page)} className="flex items-start gap-4 p-4 rounded-2xl hover:bg-gray-50 transition-colors text-left rtl:text-right group">
                        <div className="bg-indigo-50 text-indigo-600 p-3 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                          {item.icon}
                        </div>
                        <div>
                          <div className="font-bold text-gray-900 group-hover:text-indigo-600">{item.title}</div>
                          <div className="text-xs text-gray-500 mt-0.5">{item.desc}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Support Mega Menu */}
            <div className="relative group/mega" onMouseEnter={() => setActiveMegaMenu('support')} onMouseLeave={() => setActiveMegaMenu(null)}>
              <button className={`flex items-center gap-1 px-4 py-2 text-sm font-bold transition-all ${activeMegaMenu === 'support' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'}`}>
                Support <ChevronDown className={`w-4 h-4 transition-transform ${activeMegaMenu === 'support' ? 'rotate-180' : ''}`} />
              </button>
              {activeMegaMenu === 'support' && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 pt-4 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="bg-white shadow-[0_20px_50px_rgba(0,0,0,0.1)] rounded-[2rem] border border-gray-100 p-6 w-[350px] flex flex-col gap-2">
                    {supportItems.map((item) => (
                      <button key={item.page} onClick={() => handleNavClick(item.page)} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-indigo-50 transition-colors text-left rtl:text-right group w-full">
                        <div className="bg-gray-50 text-gray-400 p-2 rounded-lg group-hover:bg-white group-hover:text-indigo-600 transition-all">
                          {item.icon}
                        </div>
                        <div>
                          <div className="font-bold text-gray-700 group-hover:text-indigo-600">{item.title}</div>
                          <div className="text-[10px] text-gray-400 uppercase font-black">{item.desc}</div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button onClick={() => handleNavClick('pricing')} className={`px-4 py-2 text-sm font-bold transition-all ${currentPage === 'pricing' ? 'text-indigo-600' : 'text-gray-600 hover:text-indigo-600'}`}>Pricing</button>
            
            <div className="h-6 w-px bg-gray-200 mx-2"></div>

            <div className="flex items-center gap-3">
              <button onClick={() => setIsRtl(!isRtl)} className="p-2.5 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-all" title="Toggle RTL/LTR"><Languages className="w-5 h-5" /></button>
              <button onClick={() => handleNavClick('client-dashboard')} className="gradient-bg text-white px-8 py-3 rounded-2xl text-sm font-black hover:scale-105 active:scale-95 transition-all shadow-lg shadow-indigo-100 flex items-center gap-2">
                <Users className="w-4 h-4" /> Client Area
              </button>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center gap-2">
             <button onClick={() => setIsOpen(!isOpen)} className="bg-gray-50 p-2 rounded-xl text-gray-600">
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="lg:hidden bg-white border-b border-gray-100 h-screen overflow-y-auto p-6 animate-in slide-in-from-right duration-300">
          <div className="space-y-6">
            <button onClick={() => handleNavClick('home')} className="w-full text-left rtl:text-right py-2 text-2xl font-black text-gray-900 border-b border-gray-50">Home</button>
            <button onClick={() => handleNavClick('client-dashboard')} className="w-full gradient-bg text-white py-5 rounded-2xl font-black text-xl shadow-xl flex items-center justify-center gap-3">
              <Users className="w-6 h-6" /> Client Dashboard
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;