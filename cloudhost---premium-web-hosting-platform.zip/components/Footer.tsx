
import React from 'react';
import { Github, Twitter, Linkedin, Facebook, Cloud } from 'lucide-react';
import { Page } from '../types';

interface FooterProps {
  setCurrentPage: (page: Page) => void;
}

const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  return (
    <footer className="bg-gray-900 text-gray-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <div 
              className="flex items-center gap-3 cursor-pointer group" 
              onClick={() => setCurrentPage('home')}
            >
              <div className="gradient-bg p-2 rounded-lg text-white group-hover:scale-110 transition-transform">
                <Cloud className="w-6 h-6" />
              </div>
              <span className="text-2xl font-black text-white font-poppins">CloudHost</span>
            </div>
            <p className="text-sm leading-relaxed">
              Empowering developers and businesses with scalable, high-performance hosting solutions since 2015. 
            </p>
            <div className="flex space-x-4">
              <Facebook className="w-5 h-5 cursor-pointer hover:text-white" />
              <Twitter className="w-5 h-5 cursor-pointer hover:text-white" />
              <Linkedin className="w-5 h-5 cursor-pointer hover:text-white" />
              <Github className="w-5 h-5 cursor-pointer hover:text-white" />
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 font-poppins">Hosting</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => setCurrentPage('shared-hosting')} className="hover:text-white transition-colors">Shared Hosting</button></li>
              <li><button onClick={() => setCurrentPage('cloud-vps')} className="hover:text-white transition-colors">Cloud VPS</button></li>
              <li><button onClick={() => setCurrentPage('dedicated-servers')} className="hover:text-white transition-colors">Dedicated Servers</button></li>
              <li><button onClick={() => setCurrentPage('domains')} className="hover:text-white transition-colors">Domain Names</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 font-poppins">Company</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => setCurrentPage('about')} className="hover:text-white transition-colors">About Us</button></li>
              <li><button onClick={() => setCurrentPage('contact')} className="hover:text-white transition-colors">Contact</button></li>
              <li><button onClick={() => setCurrentPage('affiliate')} className="hover:text-white transition-colors">Affiliate Program</button></li>
              <li><button onClick={() => setCurrentPage('careers')} className="hover:text-white transition-colors">Careers</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 font-poppins">Newsletter</h4>
            <p className="text-sm mb-4">Get the latest hosting news and special offers.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-gray-800 border-none rounded-l-lg px-4 py-2 text-sm w-full focus:ring-1 focus:ring-indigo-500 outline-none"
              />
              <button className="bg-indigo-600 text-white px-4 py-2 rounded-r-lg text-sm font-semibold hover:bg-indigo-700 transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs">© 2024 CloudHost Inc. All rights reserved.</p>
          <div className="flex space-x-6 text-xs">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
            <a href="#" className="hover:text-white">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
