import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar.tsx';
import Footer from './components/Footer.tsx';
import HostingAdvisor from './components/HostingAdvisor.tsx';
import Home from './pages/Home.tsx';
import Services from './pages/Services.tsx';
import Pricing from './pages/Pricing.tsx';
import About from './pages/About.tsx';
import Contact from './pages/Contact.tsx';
import Domains from './pages/Domains.tsx';
import Blog from './pages/Blog.tsx';
import BlogPost from './pages/BlogPost.tsx';
import SharedHosting from './pages/SharedHosting.tsx';
import CPanelHosting from './pages/CPanelHosting.tsx';
import CloudVPS from './pages/CloudVPS.tsx';
import DedicatedServers from './pages/DedicatedServers.tsx';
import Affiliate from './pages/Affiliate.tsx';
import Careers from './pages/Careers.tsx';
import ClientDashboard from './pages/whmcs/ClientDashboard.tsx';
import Knowledgebase from './pages/whmcs/Knowledgebase.tsx';
import SupportTickets from './pages/whmcs/SupportTickets.tsx';
import { Page, ThemeColor } from './types.ts';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isRtl, setIsRtl] = useState(false);
  const [themeColor, setThemeColor] = useState<ThemeColor>('blue');

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  // Apply Theme Class
  useEffect(() => {
    document.body.className = `bg-gray-50 text-gray-900 transition-colors duration-300 theme-${themeColor}`;
  }, [themeColor]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <Home />;
      case 'services': return <Services />;
      case 'pricing': return <Pricing />;
      case 'about': return <About />;
      case 'contact': return <Contact />;
      case 'domains': return <Domains />;
      case 'shared-hosting': return <SharedHosting />;
      case 'cpanel-hosting': return <CPanelHosting />;
      case 'cloud-vps': return <CloudVPS />;
      case 'dedicated-servers': return <DedicatedServers />;
      case 'affiliate': return <Affiliate />;
      case 'careers': return <Careers />;
      case 'client-dashboard': return <ClientDashboard setCurrentPage={setCurrentPage} />;
      case 'knowledgebase': return <Knowledgebase />;
      case 'support-tickets': return <SupportTickets />;
      case 'blog': return <Blog setCurrentPage={setCurrentPage} />;
      case 'blog-post': return <BlogPost setCurrentPage={setCurrentPage} />;
      default: return <Home />;
    }
  };

  return (
    <div 
      dir={isRtl ? 'rtl' : 'ltr'} 
      className={`min-h-screen flex flex-col selection:bg-indigo-100 selection:text-indigo-900 ${isRtl ? 'font-arabic' : ''}`}
    >
      <Navbar 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage} 
        isRtl={isRtl} 
        setIsRtl={setIsRtl}
        themeColor={themeColor}
        setThemeColor={setThemeColor}
      />
      
      <main className="flex-grow">
        {renderPage()}
      </main>

      <Footer setCurrentPage={setCurrentPage} />
      
      {/* AI Assistant */}
      <HostingAdvisor />
    </div>
  );
}

export default App;